# zonaprop-scraper

Scraper de avisos de [ZonaProp](https://www.zonaprop.com.ar) en Node.js + Puppeteer. Recorre
búsquedas (listado) y después visita la ficha de cada aviso (detalle). Pensado para armar un
dataset de propiedades para análisis: sale JSONL y CSV listos para pandas.

Los parsers están verificados contra capturas reales del sitio de septiembre 2026
(`test/fixtures/`, tomadas del repo [Foquitos/zonaprop](https://github.com/Foquitos/zonaprop)).

## Requisitos

- Node 20+ (probado con 22)
- Google Chrome instalado (recomendado; si no está, usa el Chromium que baja Puppeteer)
- Conexión residencial. ZonaProp está detrás de Cloudflare y bloquea IPs de datacenter/VPN,
  así que **no corre desde la nube**.

```bash
npm install          # baja Chromium (~150 MB). Si vas a usar tu Chrome: PUPPETEER_SKIP_DOWNLOAD=1 npm install
npm test             # parsers contra las capturas reales: tiene que dar 8/8
```

## Flujo

1. **Armá las búsquedas en `config.js`.** Lo más seguro es hacer la búsqueda en el sitio con
   los filtros que quieras y pegar la URL de la primera página. Cada target necesita
   `esperarEnH1`: un texto que tiene que aparecer en el `<h1>` de la página de resultados.
   Es la única defensa contra un slug mal escrito, porque **ZonaProp no devuelve 404**: con un
   slug inválido te da 200 y avisos de cualquier lado (ej. `zona-norte` → 45.000 avisos de todo
   el país; `san-martin` → San Martín, Mendoza).

2. **Validá cada zona nueva con `inspect`** antes de scrapear en serio:
   ```bash
   node scripts/inspect.js https://www.zonaprop.com.ar/departamentos-venta-rosario.html
   ```
   Te abre el navegador, guarda HTML + captura en `debug/`, e imprime el `h1`, cuántas tarjetas
   parseó y el primer registro. Si el `h1` no dice lo que esperabas, el slug está mal.

3. **Primera corrida con ventana** (`headless: false`, el default):
   ```bash
   npm run scrape
   ```
   Si Cloudflare tira el challenge, el script se queda quieto y te avisa por consola: tildás el
   casillero en la ventana y sigue solo. La cookie queda en `.perfil-chrome/`; las corridas
   siguientes no la vuelven a pedir por un buen rato y ahí sí podés pasar a `--headless`.

4. **Exportá:**
   ```bash
   npm run csv          # data/listings.csv y data/details.csv
   ```

Flags de `scrape`:

| Flag | Qué hace |
| --- | --- |
| `--solo-listado` | sólo fase 1 |
| `--solo-detalle` | sólo fase 2, sobre lo que haya en `data/listings.jsonl` |
| `--limite N` | tope de fichas a visitar en esta corrida (para probar: `--limite 10`) |
| `--headless` | sin ventana; recién cuando ya tengas la cookie guardada |

Todo se guarda línea a línea en `data/*.jsonl`. Podés cortar con Ctrl+C cuando quieras y la
corrida siguiente retoma: el listado deduplica por `id`, la fase 2 sólo visita fichas que no
estén en `details.jsonl`. Los errores quedan en `data/failures.jsonl`.

## Qué sale

**`listings.jsonl`** (una línea por tarjeta del listado): `id`, `url`, `title`,
`price_currency`, `price`, `expensas`, `superficie_total`, `superficie_cubierta`, `ambientes`,
`dormitorios`, `banos`, `cocheras`, `address`, `location`, `description_short`, `publisher`,
`date_posted`, `highlight`, `pills`, `photos`, `search_slug`, `tipo`, `operacion`, `zona`,
`page`, `search_url`, `scraped_at`.

**`details.jsonl`** (una línea por ficha, incluye todo lo anterior más): `tipo_propiedad`,
`status`, `reserved`, `posting_code`, `antiguedad`, `antiguedad_texto` (`A estrenar`, `En pozo`),
`disposicion`, `orientacion`, `luminosidad`, `features_extra`, `address_locality`,
`address_region`, `neighborhood`, `city`, `province`, `location_ids`, `amenities` (por
categoría), `amenities_flat`, `description` (completa), `published_text`, `published_days`,
`publisher_id`, `publisher_url`, `publisher_premium`, `photos` (galería completa en 1200px).

Convenciones que importan para el análisis:

- `price: null` = "Consultar precio". `expensas: null` = **no informa**, que no es lo mismo que
  cero. Si querés detectar "sin expensas" declarado, buscalo en `description`.
- `price` viene en la moneda de `price_currency` (USD o ARS). No se convierte.
- **No hay coordenadas.** La ficha no las trae (verificado en septiembre 2026). Si las
  necesitás, geocodificá `address + city + province` con Nominatim o la API de Georef de
  Argentina. Los `location_ids` internos sirven para agrupar por barrio sin geocodificar.
- `published_days` es relativo a `scraped_at`.

## Cómo funciona por dentro

```
config.js              targets, límites, navegador, salida
src/scrape.js          orquestación: fase 1 (listado) → fase 2 (fichas)
src/browser.js         Puppeteer + stealth, perfil persistente, detección y espera del challenge
src/urls.js            paginación y slugs
src/parse/listing.js   tarjetas [data-qa="posting PROPERTY"] + JSON-LD (inmobiliaria, fecha)
src/parse/detail.js    objetos JS inline de la ficha (mainFeatures, publisher, avisoInfo, ...)
src/parse/util.js      números es-AR, precios, extracción de literales JS, JSON-LD
src/storage.js         JSONL append-only con índice para dedup/resume
scripts/inspect.js     diagnóstico de una URL
scripts/to-csv.js      JSONL → CSV plano
test/                  parsers contra capturas reales
```

**Listado.** Cada aviso es un `<div data-qa="posting PROPERTY" data-id="…" data-to-posting="…">`
con hijos `data-qa="POSTING_CARD_PRICE"`, `expensas`, `POSTING_CARD_FEATURES`,
`POSTING_CARD_LOCATION`, `POSTING_CARD_DESCRIPTION`, `POSTING_CARD_GALLERY`. Los `data-qa` los
usa ZonaProp para sus propios tests, por eso son estables. El nombre de la inmobiliaria y la
fecha de publicación no están en la tarjeta: salen de un bloque JSON-LD
(`@type: RealEstateListing`, `mainEntity[]`) que se cruza por id.

**Ficha.** Viene server-rendered con objetos JS inline que son más limpios que el DOM:
`const mainFeatures = {…}` (superficie, ambientes, antigüedad, orientación…),
`const publisher = {…}`, `const avisoInfo = {…}` (precio estructurado, expensas, estado,
amenities por categoría), `const dataLayerInfo = {…}` (operación, tipo, barrio/ciudad/provincia).
`avisoInfo` y `dataLayerInfo` son literales JS con comillas mezcladas, no JSON, así que se
leen claves sueltas (`jsKey`, `jsKeyJson`) en vez de parsearlos enteros.

**Cloudflare.** Un challenge se detecta por marcas en el HTML/título *sólo si la página no
tiene el contenido esperado* (las páginas normales también cargan scripts de Cloudflare).
Cuando se detecta, el script no navega, no recarga ni reintenta: espera hasta
`challengeTimeoutMs` chequeando cada segundo, porque cualquier `goto` recargaba justo cuando
ibas a tildar el casillero.

## Límites, ética y qué contar en el informe

- **Tope por búsqueda.** ZonaProp sirve como mucho unos cientos de resultados por URL de
  búsqueda aunque el filtro matchee decenas de miles. Para volumen, segmentá: más targets
  (barrio × tipo × operación × ambientes), no más páginas. Dedup por `id` te cubre los
  solapamientos.
- **robots.txt.** Leé <https://www.zonaprop.com.ar/robots.txt> antes de correr y decidí
  conscientemente qué vas a respetar; scrapers comerciales reportan que el sitio pide un tope de
  páginas por búsqueda. Mencionarlo en el informe suma.
- **Términos de uso.** Esto es scraping de páginas públicas con fines académicos, a ritmo
  humano (2–4,5 s entre requests, un solo navegador). No lo aceleres ni lo paralelices: además
  de ser lo correcto, es lo que hace que no te frene Cloudflare.
- **Datos personales.** Las inmobiliarias son empresas, pero la descripción puede traer nombres
  y matrículas de particulares. Para el TP, considerá anonimizar `publisher` y no publicar
  `description` cruda.
- **Reproducibilidad.** Guardá `scraped_at`, el `search_slug` y la versión del front (aparece en
  las URLs de assets, ej. `RPLISv8.321.2`) para explicar por qué un scraper de hoy puede no
  andar en seis meses.

## Cuando se rompe

1. `npm test`. Si falla, cambió el front y hay que ajustar selectores en `src/parse/`.
   Si pasa, el problema es de navegación.
2. `node scripts/inspect.js <url>` y mirá `debug/`. Si el HTML es una página de Cloudflare,
   corré con ventana y resolvé el challenge; si es una página real con 0 tarjetas, cambiaron
   el `data-qa` (abrí el HTML y buscá `data-id=`).
3. Si el challenge salta en cada página: usá el Chrome instalado (`chromeChannel: 'chrome'`),
   `blockResources: false`, subí `delayMs`, y no borres `.perfil-chrome/`.
4. Si ni con ventana pasa el casillero: hay reportes de que las IPs argentinas reciben más
   challenges que otras. Probá desde otra red antes de tocar código.
