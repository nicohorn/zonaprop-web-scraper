// Configuración del scraper. Todo lo que vas a querer tocar está acá.

export const config = {
  baseUrl: 'https://www.zonaprop.com.ar',

  // Cada target es una búsqueda. Lo más seguro es armar la búsqueda en el sitio y pegar la URL
  // de la primera página; la paginación (-pagina-N) la agrega el scraper.
  //
  // OJO: ZonaProp NO devuelve 404 con slugs inválidos. Devuelve 200 con avisos de otro lado
  // (ej. "zona-norte" trae 45.000 avisos de toda la Argentina). Por eso `esperarEnH1` es
  // obligatorio: el scraper valida que el <h1> de la página mencione la zona antes de guardar
  // nada. Abrí la URL en el navegador y copiá cómo escribe la zona el h1.
  targets: [
    { url: 'https://www.zonaprop.com.ar/departamentos-venta-rosario.html', esperarEnH1: 'Rosario' },
    { url: 'https://www.zonaprop.com.ar/casas-venta-rosario.html', esperarEnH1: 'Rosario' },
    { url: 'https://www.zonaprop.com.ar/departamentos-alquiler-rosario.html', esperarEnH1: 'Rosario' },
  ],

  // ZonaProp sirve 30 avisos por página y como máximo unos cientos de resultados por búsqueda,
  // aunque el filtro matchee miles. Para más volumen: más targets (barrios, tipos, rangos de
  // ambientes), no más páginas. Revisá robots.txt antes de subir esto (ver README).
  maxPagesPerTarget: 10,

  // Fase 2: visitar la ficha de cada aviso. Es una request por aviso, así que es la etapa lenta.
  scrapeDetails: true,
  maxDetailsPerRun: Infinity, // útil para probar: 20

  // --- Navegador -----------------------------------------------------------------------
  // Primera corrida SIEMPRE con ventana: si Cloudflare tira el challenge de Turnstile hay que
  // tildar el casillero a mano. La cookie queda en userDataDir y después podés ir headless.
  headless: false,
  // 'chrome' usa el Chrome que tenés instalado, que recibe bastantes menos challenges que el
  // Chromium que trae Puppeteer. Si no lo encuentra, cae solo al de Puppeteer. null = Puppeteer.
  chromeChannel: 'chrome',
  userDataDir: './.perfil-chrome',
  viewport: { width: 1400, height: 950 },
  // Pausa aleatoria entre páginas. No la bajes: es lo que evita que salte el challenge.
  delayMs: { min: 2000, max: 4500 },
  // Cuánto esperar a que resuelvas el casillero de Cloudflare antes de abortar.
  challengeTimeoutMs: 240_000,
  navTimeoutMs: 45_000,
  contentTimeoutMs: 20_000,
  retries: 3,
  // Bloquear imágenes/fonts acelera mucho pero es un patrón "raro" para Cloudflare. Activalo
  // recién cuando ya tengas la cookie y veas que no te frena.
  blockResources: false,

  // --- Salida --------------------------------------------------------------------------
  out: {
    dir: './data',
    listings: 'listings.jsonl',
    details: 'details.jsonl',
    failures: 'failures.jsonl',
  },
  // Guardar HTML crudo en ./debug: 'never' | 'errors' (páginas con 0 avisos, h1 inesperado,
  // fichas que no parsean) | 'all'
  saveHtml: 'errors',
};
