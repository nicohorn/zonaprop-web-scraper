// JSONL -> CSV plano, listo para pandas.
//   npm run csv                              exporta data/listings.jsonl y data/details.jsonl
//   node scripts/to-csv.js data/details.jsonl salida.csv
// Objetos anidados se aplanan con punto (location_ids.city_id); arrays se unen con ' | '.

import { existsSync, writeFileSync } from 'node:fs';
import { stringify } from 'csv-stringify/sync';
import { readJsonl } from '../src/storage.js';

function flatten(obj, prefix = '', out = {}) {
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (Array.isArray(v)) out[key] = v.map((x) => (typeof x === 'object' ? JSON.stringify(x) : x)).join(' | ');
    else if (v && typeof v === 'object') flatten(v, key, out);
    else out[key] = v ?? '';
  }
  return out;
}

function convert(inPath, outPath) {
  if (!existsSync(inPath)) { console.log(`(no existe ${inPath})`); return; }
  const rows = readJsonl(inPath).map((r) => flatten(r));
  const columns = [...new Set(rows.flatMap((r) => Object.keys(r)))];
  writeFileSync(outPath, '\uFEFF' + stringify(rows, { header: true, columns })); // BOM: Excel abre bien los acentos
  console.log(`${inPath} -> ${outPath}: ${rows.length} filas, ${columns.length} columnas`);
}

const [inArg, outArg] = process.argv.slice(2);
if (inArg) convert(inArg, outArg || inArg.replace(/\.jsonl$/, '.csv'));
else {
  convert('data/listings.jsonl', 'data/listings.csv');
  convert('data/details.jsonl', 'data/details.csv');
}
