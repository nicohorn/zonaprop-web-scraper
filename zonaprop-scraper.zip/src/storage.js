// Persistencia: JSONL append-only. Cada línea es un aviso; se escribe apenas se parsea, así
// Ctrl+C a mitad de camino no pierde nada y la corrida siguiente retoma donde quedó.

import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';

export class JsonlStore {
  constructor(path, key = 'id') {
    this.path = path;
    this.key = key;
    this.index = new Map(); // key -> registro (sólo lo ya guardado)
    mkdirSync(dirname(path), { recursive: true });
    if (existsSync(path)) {
      for (const line of readFileSync(path, 'utf8').split('\n')) {
        if (!line.trim()) continue;
        try { const o = JSON.parse(line); this.index.set(o[key], o); } catch { /* línea rota */ }
      }
    }
  }

  has(k) { return this.index.has(k); }
  get(k) { return this.index.get(k); }
  get size() { return this.index.size; }
  all() { return [...this.index.values()]; }

  append(obj) {
    appendFileSync(this.path, JSON.stringify(obj) + '\n');
    this.index.set(obj[this.key], obj);
  }
}

export function readJsonl(path) {
  if (!existsSync(path)) return [];
  return readFileSync(path, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l));
}

/** Guarda HTML crudo en ./debug para revisar selectores. Devuelve la ruta. */
export function saveDebugHtml(name, html) {
  mkdirSync('debug', { recursive: true });
  const safe = name.replace(/[^a-z0-9_-]+/gi, '_').slice(0, 120);
  const path = join('debug', `${safe}.html`);
  writeFileSync(path, html);
  return path;
}
