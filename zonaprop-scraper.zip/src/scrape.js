// Orquestación.
//   node src/scrape.js                  listado + fichas según config.js
//   node src/scrape.js --solo-listado   sólo fase 1
//   node src/scrape.js --solo-detalle   sólo fase 2 (fichas pendientes de data/listings.jsonl)
//   node src/scrape.js --limite 20      tope de fichas a visitar en esta corrida
//   node src/scrape.js --headless       fuerza headless (recién cuando ya tengas la cookie)
//
// Fase 1 recorre cada target página a página, valida el <h1> contra `esperarEnH1`, deduplica
// por id y corta cuando una página no aporta avisos nuevos. Fase 2 visita cada ficha que aún
// no está en details.jsonl. Todo se persiste línea a línea: Ctrl+C es seguro.

import { join } from 'node:path';
import { config } from '../config.js';
import { Session, humanDelay } from './browser.js';
import { pageUrl, searchSlug, parseSlug } from './urls.js';
import { parseListing, CARD_SELECTOR } from './parse/listing.js';
import { parseDetail, looksLikeDetail } from './parse/detail.js';
import { JsonlStore, saveDebugHtml } from './storage.js';
import { normalize } from './parse/util.js';

const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const opt = (name, def) => { const i = args.indexOf(name); return i >= 0 && args[i + 1] ? args[i + 1] : def; };

const soloListado = flag('--solo-listado');
const soloDetalle = flag('--solo-detalle');
const limite = Number(opt('--limite', config.maxDetailsPerRun));
const headless = flag('--headless') ? true : config.headless;

const out = (f) => join(config.out.dir, f);
const listings = new JsonlStore(out(config.out.listings));
const details = new JsonlStore(out(config.out.details));
const failures = new JsonlStore(out(config.out.failures), 'key');

const ts = () => new Date().toISOString().slice(11, 19);
const log = (...a) => console.log(ts(), ...a);

function shouldSaveHtml(isError) {
  return config.saveHtml === 'all' || (config.saveHtml === 'errors' && isError);
}

// ------------------------------------------------------------------------------------------
async function scrapeListings(session) {
  log(`Fase 1: ${config.targets.length} búsquedas, hasta ${config.maxPagesPerTarget} páginas c/u. Ya guardados: ${listings.size} avisos.`);

  for (const target of config.targets) {
    const slug = searchSlug(target.url);
    const ctx = { search_slug: slug, ...parseSlug(slug) };
    log(`\n▶ ${slug}`);

    for (let page = 1; page <= config.maxPagesPerTarget; page++) {
      const url = pageUrl(target.url, page);
      let html;
      try {
        html = await session.goto(url, { contentSelector: CARD_SELECTOR });
        await session.scroll(3);
        html = await session.page.content(); // después del scroll hay más imágenes cargadas
      } catch (e) {
        log(`  p${page}: ERROR ${e.message}`);
        failures.append({ key: url, phase: 'listing', url, error: e.message, at: new Date().toISOString() });
        break;
      }

      const { h1, total_results, items } = parseListing(html, { ...ctx, page, search_url: url });

      // ZonaProp no tira 404 con slugs raros: devuelve 200 con avisos de cualquier lado.
      if (target.esperarEnH1 && !normalize(h1).includes(normalize(target.esperarEnH1))) {
        const dbg = saveDebugHtml(`h1-inesperado-${slug}-p${page}`, html);
        log(`  p${page}: el h1 dice "${h1}" y esperaba "${target.esperarEnH1}". Slug mal armado. Salto el target. (HTML en ${dbg})`);
        failures.append({ key: url, phase: 'listing', url, error: `h1 inesperado: ${h1}`, at: new Date().toISOString() });
        break;
      }

      if (items.length === 0) {
        if (shouldSaveHtml(true)) saveDebugHtml(`sin-avisos-${slug}-p${page}`, html);
        log(`  p${page}: 0 avisos (fin de resultados o cambió el front; ver debug/). Corto.`);
        break;
      }
      if (shouldSaveHtml(false)) saveDebugHtml(`listado-${slug}-p${page}`, html);

      let nuevos = 0;
      for (const it of items) {
        if (listings.has(it.id)) continue;
        listings.append(it);
        nuevos++;
      }
      log(`  p${page}: ${items.length} avisos, ${nuevos} nuevos (total búsqueda: ${total_results ?? '?'}, guardados: ${listings.size})`);

      // Pasada la última página ZonaProp repite resultados: si nada es nuevo, terminamos.
      if (nuevos === 0 && page > 1) { log('  Sin avisos nuevos: última página alcanzada.'); break; }
      if (total_results && page * 30 >= total_results) { log('  Cubrí el total declarado.'); break; }

      await humanDelay();
    }
  }
}

// ------------------------------------------------------------------------------------------
async function scrapeDetails(session) {
  const pending = listings.all().filter((l) => !details.has(l.id) && !failures.has(`detail:${l.id}`));
  const batch = pending.slice(0, limite);
  log(`\nFase 2: ${pending.length} fichas pendientes, visito ${batch.length} en esta corrida (ya guardadas: ${details.size}).`);

  for (const [i, l] of batch.entries()) {
    const label = `[${i + 1}/${batch.length}] ${l.id}`;
    try {
      const html = await session.goto(l.url, { contentSelector: '#longDescription, .price-value, h1' });
      if (!looksLikeDetail(html)) {
        const dbg = shouldSaveHtml(true) ? saveDebugHtml(`ficha-rara-${l.id}`, html) : '';
        log(`${label}: no parece una ficha (¿aviso dado de baja?). ${dbg}`);
        failures.append({ key: `detail:${l.id}`, phase: 'detail', url: l.url, error: 'no parece ficha', at: new Date().toISOString() });
      } else {
        if (shouldSaveHtml(false)) saveDebugHtml(`ficha-${l.id}`, html);
        const d = parseDetail(html, l);
        details.append(d);
        log(`${label}: ${d.tipo_propiedad ?? '?'} ${d.price_currency ?? ''} ${d.price ?? '?'} · ${d.superficie_total ?? '?'} m² · ${d.neighborhood ?? d.location ?? ''}`);
      }
    } catch (e) {
      log(`${label}: ERROR ${e.message.split('\n')[0]}`);
      failures.append({ key: `detail:${l.id}`, phase: 'detail', url: l.url, error: e.message, at: new Date().toISOString() });
      if (/verificación seguía sin resolverse/.test(e.message)) throw e; // no tiene sentido seguir
    }
    await humanDelay();
  }
}

// ------------------------------------------------------------------------------------------
const session = new Session({ headless, log });
process.on('SIGINT', async () => { log('\nCtrl+C: cierro el navegador. Lo guardado hasta acá queda en data/.'); await session.close(); process.exit(130); });

try {
  await session.launch();
  if (!soloDetalle) await scrapeListings(session);
  if (!soloListado && config.scrapeDetails) await scrapeDetails(session);
  log(`\nListo. listings: ${listings.size} · details: ${details.size} · fallos: ${failures.size}`);
  log(`Exportar a CSV: npm run csv`);
} catch (e) {
  log(`ABORTADO: ${e.message}`);
  process.exitCode = 1;
} finally {
  await session.close();
}
